<?php


$servidor='localhost';
$usuario='root';
$clave='';
$based= 'sistema de pedidos';


//funcion que nos conecta a mysql
$conexion=mysqli_connect($servidor,$usuario,$clave) or die ('no se conecto a mysql');


//conecta a la base de datos
mysqli_select_db($conexion,$based) or die ('no se encontro a sistema de pedidos');


//utf8 para que todos los simbolos salgan bien
mysqli_set_charset($conexion,'utf8');









?>