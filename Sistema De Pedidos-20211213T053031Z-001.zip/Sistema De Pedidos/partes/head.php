<?php
session_start();
require_once('clases/conexion.php');
require_once('clases/sentencia.php');                                                                                       

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>APLICACIÓN DE PEDIDOS</title>

<!-- llama a la hoja de estilo que vamos a crear nosotros -->
<link href="bootstrap-4.4.1-dist/bootstrap-4.4.1-dist/css/estilo.css" type="text/css" rel="stylesheet">
<script src="ckeditor/ckeditor.js"></script>

<!-- llama a la hoja de estilo de boostrap -->
<link href="stylesheet" href="css/bootstrap.min.css" integrity="sha384-
F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">




</head>
<body>





</body>
</html>


